
// Function to handle the login process
function login() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // Simulate a server request (replace with actual server communication)
    setTimeout(function() {
        if (username === 'demo' && password === 'password') {
            alert('Login successful! Redirecting...'); // You can redirect the user to another page here.
        } else {
            alert('Login failed. Please check your username and password.');
        }
    }, 1000); // Simulate a delay as if sending a request to a server
}

// Add a click event listener to the login button
document.getElementById('login-button').addEventListener('click', function(event) {
    event.preventDefault(); // Prevent the form from submitting
    login();
});

// Add an event listener for the Enter key in the password field
document.getElementById('password').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        event.preventDefault(); // Prevent the form from submitting
        login();
    }
});